﻿using System;
using System.Collections.Generic;
using System.Text;

namespace APIMUserNormalization.Models
{
    public enum GroupType
    {
    }
}

